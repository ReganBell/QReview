*************
Blockmodeling
*************

.. automodule:: networkx.algorithms.block
.. autosummary::
   :toctree: generated/

   blockmodel
