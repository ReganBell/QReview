********
Vitality
********

.. automodule:: networkx.algorithms.vitality
.. autosummary::
   :toctree: generated/

   closeness_vitality
